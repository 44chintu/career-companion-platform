from django.conf import settings
from django.urls import path
from . import views
from django.conf.urls.static import static

urlpatterns = [
    path('profile/', views.profile, name='profile'),
    path('skill-cloud/', views.skill_cloud, name='skill_cloud'),
    path('progres_tracker/', views.progress_tracker, name='progress_tracker'),
    path('timeLineView/', views.timeline, name='timeLineView'),
    path('resumeGenerator/', views.resume_generator, name='resumeGenerator'),
    path('learninHub/', views.learning_hub, name='learningHub'),
    path('dashboardPage', views.dashboardPage, name='dashboardPage'),
    path('', views.index, name='index'),
    path('logout/', views.logout, name='logout'),
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup')
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
