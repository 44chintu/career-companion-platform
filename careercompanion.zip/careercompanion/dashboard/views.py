from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm, UserUpdateForm, ProfileUpdateForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

def index(request):
    return render(request, 'dashboard/index.html')
# @login_required
def skill_cloud(request):
    return render(request, 'dashboard/skill_cloud.html')

def dashboardPage(request):
    return render(request, 'dashboard/dashboardPage.html')

def logout(request):
    return render(request, 'dashboard/index.html')

# @login_required
def progress_tracker(request):
    return render(request, 'dashboard/progress_tracker.html')

# @login_required
def timeline(request):
    return render(request, 'dashboard/timeLineView.html')

# @login_required
def resume_generator(request):
    return render(request, 'dashboard/resumeGenerator.html')

# @login_required
def learning_hub(request):
    return render(request, 'dashboard/learningHub.html')

def login(request):
    return render(request, 'dashboard/login.html')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Auto-login after signup
            return redirect('dashboardPage')  # Go to profile page
    else:
        form = SignUpForm()
    
    return render(request, 'dashboard/signup.html', {'form': form})

def profile(request):
    u_form = None
    p_form = None
    skills_count = 0
    projects_count = 0
    applications_count = 0

    if request.user.is_authenticated:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)

        # Example: Replace with your real queries
        skills_count = request.user.profile.skills.count() if hasattr(request.user.profile, 'skills') else 0
        projects_count = request.user.profile.projects.count() if hasattr(request.user.profile, 'projects') else 0
        applications_count = request.user.profile.applications.count() if hasattr(request.user.profile, 'applications') else 0

    context = {
        'u_form': u_form,
        'p_form': p_form,
        'skills_count': skills_count,
        'projects_count': projects_count,
        'applications_count': applications_count
    }
    return render(request, 'dashboard/profile.html', context)